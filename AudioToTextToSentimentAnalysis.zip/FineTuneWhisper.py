import os
import torch
import torchaudio
from datasets import Dataset
from torch.utils.data import DataLoader
from torch.nn.utils.rnn import pad_sequence
from transformers import WhisperProcessor, WhisperForConditionalGeneration, pipeline
from jiwer import wer, cer
from sklearn.metrics import classification_report
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay



# Paths
AUDIO_DIR = "audios"
MODEL_NAME = "openai/whisper-small"

# Load processor and model
processor = WhisperProcessor.from_pretrained(MODEL_NAME)
model = WhisperForConditionalGeneration.from_pretrained(MODEL_NAME)

# Freeze encoder 
for param in model.model.encoder.parameters():
    param.requires_grad = False

# Audio loader function
def load_audio(file_path):
    waveform, sr = torchaudio.load(file_path)
    if sr != 16000:
        waveform = torchaudio.transforms.Resample(orig_freq=sr, new_freq=16000)(waveform)
    return waveform.mean(dim=0), 16000

# Load and prepare data
data = {"audio": [], "text": []}
for folder in os.listdir(AUDIO_DIR):
    folder_path = os.path.join(AUDIO_DIR, folder)
    if os.path.isdir(folder_path):
        for file in os.listdir(folder_path):
            if file.endswith(".wav"):
                audio_path = os.path.join(folder_path, file)
                txt_path = audio_path.replace(".wav", ".txt")

                if not os.path.exists(txt_path):
                    waveform, sr = load_audio(audio_path)
                    inputs = processor(waveform, sampling_rate=sr, return_tensors="pt")
                    pred_ids = model.generate(inputs.input_features)
                    transcription = processor.batch_decode(pred_ids, skip_special_tokens=True)[0]
                    with open(txt_path, "w", encoding="utf-8") as f:
                        f.write(transcription)

                with open(txt_path, "r", encoding="utf-8") as f:
                    data["audio"].append(audio_path)
                    data["text"].append(f.read().strip())

# Create dataset and split
dataset = Dataset.from_dict(data).train_test_split(test_size=0.2)

# Preprocess function to return tensors only
def preprocess(example):
    waveform, sr = load_audio(example["audio"])
    inputs = processor(waveform, sampling_rate=sr, return_tensors="pt")
    input_features = inputs.input_features.squeeze(0)  # [seq_len, feature_dim] tensor

    labels = processor.tokenizer(example["text"], return_tensors="pt").input_ids.squeeze(0)  # tensor

    return {"input_features": input_features, "labels": labels}

dataset = dataset.map(preprocess, remove_columns=["audio", "text"])

# Collator to pad tensors
class Collator:
    def __init__(self, processor):
        self.pad_token = processor.tokenizer.pad_token_id

    def __call__(self, batch):
        input_features = pad_sequence(
            [x["input_features"] if isinstance(x["input_features"], torch.Tensor) else torch.tensor(x["input_features"]) for x in batch],
            batch_first=True,
        )
        labels = pad_sequence(
            [x["labels"] if isinstance(x["labels"], torch.Tensor) else torch.tensor(x["labels"]) for x in batch],
            batch_first=True,
            padding_value=self.pad_token,
        )
        return {"input_features": input_features, "labels": labels}

collator = Collator(processor)

# Data loaders
train_loader = DataLoader(dataset["train"], batch_size=2, shuffle=True, collate_fn=collator)
test_loader = DataLoader(dataset["test"], batch_size=2, collate_fn=collator)

# Optimizer
optimizer = torch.optim.AdamW(model.parameters(), lr=5e-5)
train_losses = []

# Training loop (simple 2 epochs)
for epoch in range(10):
    running_loss = 0.0
    for batch in train_loader:
        optimizer.zero_grad()
        outputs = model(input_features=batch["input_features"], labels=batch["labels"])
        loss = outputs.loss
        loss.backward()
        optimizer.step()
        running_loss += loss.item()
    
    avg_loss = running_loss / len(train_loader)
    train_losses.append(avg_loss)
    print(f"Epoch {epoch + 1} complete. Avg Loss: {avg_loss:.4f}")

plt.plot(range(1, len(train_losses) + 1), train_losses, marker='o')
plt.title('Training Loss over Epochs')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.grid(True)
plt.show()

# Transcription function
def transcribe_audio(file_path):
    waveform, sr = load_audio(file_path)
    inputs = processor(waveform, sampling_rate=sr, return_tensors="pt")
    pred_ids = model.generate(inputs.input_features)
    return processor.batch_decode(pred_ids, skip_special_tokens=True)[0]


# Sentiment analysis pipeline (small, fast model)
sentiment_pipeline = pipeline("sentiment-analysis", model="cardiffnlp/twitter-roberta-base-sentiment")
label_map = {
    "LABEL_0": "Negative",
    "LABEL_1": "Neutral",
    "LABEL_2": "Positive"
}
# Test transcription and sentiment
test_file = "03-01-08-01-01-02-11.wav"
transcription = transcribe_audio(test_file)
print("Transcription:", transcription)

sentiment_result = sentiment_pipeline(transcription)[0]
readable_label = label_map.get(sentiment_result["label"], "Unknown")

print(f"Sentiment: ({readable_label}), Score: {sentiment_result['score']:.3f}")


# # Function to evaluate transcription accuracy
# def evaluate_transcription(test_dataset):
#     total_wer, total_cer = 0, 0
#     num_samples = len(test_dataset)

#     for i in range(num_samples):
#         audio_path = test_dataset[i]["input_features"]  # Use stored input features
#         ground_truth = processor.tokenizer.decode(test_dataset[i]["labels"], skip_special_tokens=True)  # Decode labels
#         predicted_transcription = transcribe_audio(audio_path)

#         wer_score = wer(ground_truth, predicted_transcription)
#         cer_score = cer(ground_truth, predicted_transcription)

#         total_wer += wer_score
#         total_cer += cer_score

#         if i < 5:  # Print first few results
#             print(f"Audio: {audio_path}")
#             print(f"Actual: {ground_truth}")
#             print(f"Predicted: {predicted_transcription}")
#             print(f"WER: {wer_score:.2f}, CER: {cer_score:.2f}")
#             print("-" * 50)

#     avg_wer = total_wer / num_samples
#     avg_cer = total_cer / num_samples

#     print(f"\n📊 **Evaluation Results:**")
#     print(f"Average WER: {avg_wer:.2f}")
#     print(f"Average CER: {avg_cer:.2f}")

# # Run evaluation on test dataset
# evaluate_transcription(dataset["test"])



