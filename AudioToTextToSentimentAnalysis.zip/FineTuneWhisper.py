import os
import torch
import torchaudio
from datasets import Dataset
from torch.utils.data import DataLoader
from torch.nn.utils.rnn import pad_sequence
from transformers import WhisperProcessor, WhisperForConditionalGeneration, pipeline

# Paths
AUDIO_DIR = "audios"
MODEL_NAME = "openai/whisper-small"

# Load processor and model
processor = WhisperProcessor.from_pretrained(MODEL_NAME)
model = WhisperForConditionalGeneration.from_pretrained(MODEL_NAME)

# Set model for training 
model.train()

# Freeze encoder 
for param in model.model.encoder.parameters():
    param.requires_grad = False

# Audio loader function
def load_audio(file_path):
    waveform, sr = torchaudio.load(file_path)
    if sr != 16000:
        waveform = torchaudio.transforms.Resample(orig_freq=sr, new_freq=16000)(waveform)
    return waveform.mean(dim=0), 16000

# Load and prepare data
data = {"audio": [], "text": []}
for folder in os.listdir(AUDIO_DIR):
    folder_path = os.path.join(AUDIO_DIR, folder)
    if os.path.isdir(folder_path):
        for file in os.listdir(folder_path):
            if file.endswith(".wav"):
                audio_path = os.path.join(folder_path, file)
                txt_path = audio_path.replace(".wav", ".txt")

                if not os.path.exists(txt_path):
                    waveform, sr = load_audio(audio_path)
                    inputs = processor(waveform, sampling_rate=sr, return_tensors="pt")
                    pred_ids = model.generate(inputs.input_features)
                    transcription = processor.batch_decode(pred_ids, skip_special_tokens=True)[0]
                    with open(txt_path, "w", encoding="utf-8") as f:
                        f.write(transcription)

                with open(txt_path, "r", encoding="utf-8") as f:
                    data["audio"].append(audio_path)
                    data["text"].append(f.read().strip())

# Create dataset and split
dataset = Dataset.from_dict(data).train_test_split(test_size=0.2)

# Preprocess function to return tensors only
def preprocess(example):
    waveform, sr = load_audio(example["audio"])
    inputs = processor(waveform, sampling_rate=sr, return_tensors="pt")
    input_features = inputs.input_features.squeeze(0)  # [seq_len, feature_dim] tensor

    labels = processor.tokenizer(example["text"], return_tensors="pt").input_ids.squeeze(0)  # tensor

    return {"input_features": input_features, "labels": labels}

dataset = dataset.map(preprocess, remove_columns=["audio", "text"])

# Collator to pad tensors
class Collator:
    def __init__(self, processor):
        self.pad_token = processor.tokenizer.pad_token_id

    def __call__(self, batch):
        input_features = pad_sequence(
            [x["input_features"] if isinstance(x["input_features"], torch.Tensor) else torch.tensor(x["input_features"]) for x in batch],
            batch_first=True,
        )
        labels = pad_sequence(
            [x["labels"] if isinstance(x["labels"], torch.Tensor) else torch.tensor(x["labels"]) for x in batch],
            batch_first=True,
            padding_value=self.pad_token,
        )
        return {"input_features": input_features, "labels": labels}

collator = Collator(processor)

# Data loaders
train_loader = DataLoader(dataset["train"], batch_size=2, shuffle=True, collate_fn=collator)
test_loader = DataLoader(dataset["test"], batch_size=2, collate_fn=collator)

# Optimizer
optimizer = torch.optim.AdamW(model.parameters(), lr=5e-5)

# Training loop (simple 2 epochs)
for epoch in range(2):
    model.train()
    for batch in train_loader:
        optimizer.zero_grad()
        outputs = model(input_features=batch["input_features"], labels=batch["labels"])
        outputs.loss.backward()
        optimizer.step()
    print(f"Epoch {epoch + 1} complete.")

# Transcription function
def transcribe_audio(file_path):
    waveform, sr = load_audio(file_path)
    inputs = processor(waveform, sampling_rate=sr, return_tensors="pt")
    pred_ids = model.generate(inputs.input_features)
    return processor.batch_decode(pred_ids, skip_special_tokens=True)[0]


# Sentiment analysis pipeline (small, fast model)
sentiment_pipeline = pipeline("sentiment-analysis", model="cardiffnlp/twitter-roberta-base-sentiment")
label_map = {
    "LABEL_0": "Negative",
    "LABEL_1": "Neutral",
    "LABEL_2": "Positive"
}
# Test transcription and sentiment
test_file = data["audio"][0]
transcription = transcribe_audio(test_file)
print("Transcription:", transcription)

sentiment_result = sentiment_pipeline(transcription)[0]
readable_label = label_map.get(sentiment_result["label"], "Unknown")

print(f"Sentiment: ({readable_label}), Score: {sentiment_result['score']:.3f}")
