from transformers import  WhisperProcessor, WhisperForConditionalGeneration, pipeline
import torch 
import torchaudio


model_name="openai/whisper-small"
processor=WhisperProcessor.from_pretrained(model_name)
model=WhisperForConditionalGeneration.from_pretrained(model_name)


#audio_path="03-01-02-01-01-01-02.wav"

audio_path="angry.wav"


def load_audio(path):
    torchaudio.set_audio_backend('sox_io')
    waveform, sample_rate = torchaudio.load(path)
    if sample_rate != 16000:
        resampler = torchaudio.transforms.Resample(orig_freq=sample_rate, new_freq=16000)
        waveform = resampler(waveform)
    if waveform.ndim > 1:
        waveform = torch.mean(waveform, dim=0)
    return waveform, 16000

def transcribe_and_analyze(audio_path):
    audio, sr = load_audio(audio_path)
    inputs = processor(audio, sampling_rate=sr, return_tensors="pt")
    predicted_ids = model.generate(inputs.input_features)
    transcription = processor.batch_decode(predicted_ids, skip_special_tokens=True)[0]

    sentiment_pipeline = pipeline("sentiment-analysis", model="cardiffnlp/twitter-roberta-base-sentiment")
    sentiment = sentiment_pipeline(transcription)[0]

    label_map = {
        "LABEL_0": "Negative",
        "LABEL_1": "Neutral",
        "LABEL_2": "Positive"
    }

    readable_label = label_map.get(sentiment["label"], "Unknown")

    print("Transcription:", transcription)
    print(f"Sentiment: {readable_label} (Confidence: {sentiment['score']:.2f})")


transcribe_and_analyze(audio_path)
